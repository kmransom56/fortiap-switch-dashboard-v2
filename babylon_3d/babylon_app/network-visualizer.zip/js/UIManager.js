class UIManager {
    constructor() {
        this.setupUI();
    }
    
    setupUI() {
        // UI setup handled in HTML
    }
}